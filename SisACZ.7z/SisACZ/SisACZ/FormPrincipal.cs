﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisACZ
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void usúarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUsuario usu = new FormUsuario();
            usu.Show();
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormProduto pro = new FormProduto();
            pro.Show();
        }

        private void mesaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMesa mes = new FormMesa();
            mes.Show();
        }

        private void vendaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVenda ven = new FormVenda();
            ven.Show();
        }

        private void pbMesas_Click(object sender, EventArgs e)
        {
            FormMesa mes = new FormMesa();
            mes.Show();
        }

        private void pbProdutos_Click(object sender, EventArgs e)
        {
            FormProduto pro = new FormProduto();
            pro.Show();
        }

        private void PbUsuarios_Click(object sender, EventArgs e)
        {
            FormUsuario usu = new FormUsuario();
            usu.Show();
        }

        private void pbVendas_Click(object sender, EventArgs e)
        {
            FormVenda ven = new FormVenda();
            ven.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
